export default () => import('./AsyncComponent');
