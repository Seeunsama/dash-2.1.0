# @plotly/eslint-config-dash

Shareable linting configurations for Dash projects.