export default () => import(/* webpackChunkName: "dropdown" */ '../../fragments/Dropdown.react');

